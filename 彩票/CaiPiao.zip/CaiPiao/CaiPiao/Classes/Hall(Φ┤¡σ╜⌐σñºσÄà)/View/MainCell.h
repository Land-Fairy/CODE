//
//  MainCell.h
//  FirstVC
//
//  Created by mac on 2017/3/18.
//  Copyright © 2017年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainCell : UICollectionViewCell
@property(nonatomic,strong)UIImageView *Ima;
- (void)getCell:(NSString *)str;
@end
