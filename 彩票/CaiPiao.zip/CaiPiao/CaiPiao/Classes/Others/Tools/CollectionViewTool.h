//
//  CollectionViewTool.h
//  CollectionView布局效果
//
//  Created by 张泽楠 on 15/12/24.
//  Copyright © 2015年 张泽楠. All rights reserved.
//

#ifndef CollectionViewTool_h
#define CollectionViewTool_h

#import "UICollectionView+Regist.h"
#import "UICollectionViewCell+Reuse.h"

#endif /* CollectionViewTool_h */
