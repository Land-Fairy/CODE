//
//  UICollectionViewCell+Reuse.h
//  CollectionView布局效果
//
//  Created by 张泽楠 on 15/12/24.
//  Copyright © 2015年 张泽楠. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UICollectionViewCell (Reuse)
+ (NSString *)reuseStr;
@end













