//
//  UICollectionViewCell+Reuse.m
//  CollectionView布局效果
//
//  Created by 张泽楠 on 15/12/24.
//  Copyright © 2015年 张泽楠. All rights reserved.
//

#import "UICollectionViewCell+Reuse.h"

@implementation UICollectionViewCell (Reuse)

+ (NSString *)reuseStr {
    return NSStringFromClass(self);
}

@end









